import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.*;

public class Arbitro {

    private static final Logger logger = Logger.getLogger(Arbitro.class.getName());

    public static void main(String[] args) throws InterruptedException {
        // Configurar el Logger
        ConsoleHandler consoleHandler = new ConsoleHandler();
        consoleHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(consoleHandler);
        
        logger.info("¡Iniciando la carrera de postas!");
        
        // Crear equipos
        Equipo equipo1 = crearEquipo("Equipo 1");
        Equipo equipo2 = crearEquipo("Equipo 2");
        Equipo equipo3 = crearEquipo("Equipo 3");
        Equipo equipo4 = crearEquipo("Equipo 4");

        // Iniciar la carrera
        long startTime = System.currentTimeMillis();

        equipo1.iniciarCarrera();
        equipo2.iniciarCarrera();
        equipo3.iniciarCarrera();
        equipo4.iniciarCarrera();

        // Esperar resultados
        equipo1.esperarResultados();
        equipo2.esperarResultados();
        equipo3.esperarResultados();
        equipo4.esperarResultados();

        long endTime = System.currentTimeMillis();

        // Calcular el tiempo total de la carrera
        long totalTime = endTime - startTime;
        System.out.printf("Carrera finalizada en: %d minutos y %d segundos\n", TimeUnit.MILLISECONDS.toMinutes(totalTime),
                TimeUnit.MILLISECONDS.toSeconds(totalTime) % 60);

        // Determinar ganador
        List<Equipo> equipos = Arrays.asList(equipo1, equipo2, equipo3, equipo4);
        equipos.sort(Comparator.comparingLong(Equipo::getTiempoTotal));

        // Mostrar el podio
        System.out.println("Podio Final:");
        for (int i = 0; i < equipos.size(); i++) {
            Equipo equipo = equipos.get(i);
            System.out.printf("Posición %d: %s - Tiempo Total: %dms\n", i + 1, equipo.getNombreEquipo(), equipo.getTiempoTotal());
        }
    }

    // Método para crear un equipo con 4 atletas
    private static Equipo crearEquipo(String nombreEquipo) {
        Equipo equipo = new Equipo(nombreEquipo);
        String[] actividades = {"Remo", "Correr", "Nadar", "Bici"};

        for (String actividad : actividades) {
            Atleta atleta = new Atleta("Atleta " + actividad, actividad, equipo);
            equipo.agregarAtleta(atleta);
        }

        return equipo;
    }
}

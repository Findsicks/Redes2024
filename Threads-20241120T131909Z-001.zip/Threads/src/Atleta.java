import java.util.Random;

public class Atleta extends Thread {
    private final String nombre;
    private final String actividad;
    private final long tiempoActividad;  // Tiempo que tarda en completar su actividad
    private final Equipo equipo;
    private boolean tienePosta = true;   // Indica si el atleta tiene la posta

    public Atleta(String nombre, String actividad, Equipo equipo) {
        this.nombre = nombre;
        this.actividad = actividad;
        this.equipo = equipo;
        // Generar un tiempo aleatorio entre 300ms y 3000ms
        Random rand = new Random();
        this.tiempoActividad = 300 + rand.nextInt(2700); // 300ms - 3000ms
    }

    public String getActividad() {
        return actividad;
    }

    public long getTiempoActividad() {
        return tiempoActividad;
    }

    @Override
    public void run() {
        try {
            // Simula el inicio de la actividad
            if (tienePosta) {
                long startTime = System.currentTimeMillis();  // Iniciar cronómetro
                System.out.printf("\033[34mAtleta %s (Equipo: %s) empieza %s, estimado: %dms\n", 
                                  getName(), equipo.getNombreEquipo(), actividad, tiempoActividad);

                // El atleta realiza su actividad (sleep simula el tiempo)
                Thread.sleep(tiempoActividad); 

                long elapsedTime = System.currentTimeMillis() - startTime;
                equipo.actualizarTiempoTotal(elapsedTime);

                System.out.printf("\033[32mAtleta %s (Equipo: %s) ha completado %s. Tiempo: %dms, Acumulado: %dms\n", 
                                  getName(), equipo.getNombreEquipo(), actividad, elapsedTime, equipo.getTiempoTotal());

                // El atleta pasa la posta al siguiente miembro
                tienePosta = false;
                equipo.pasarPostaAlSiguiente();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public boolean tienePosta() {
        return tienePosta;
    }

    public void pasarPosta() {
        this.tienePosta = true;
    }
}

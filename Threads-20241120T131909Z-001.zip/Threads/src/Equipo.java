import java.util.ArrayList;

public class Equipo {
    private final String nombreEquipo;
    private final ArrayList<Atleta> atletas;
    private long tiempoTotal;  // Tiempo total del equipo
    private int indiceActualAtleta;  // Indice del siguiente atleta que debe correr

    public Equipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
        this.atletas = new ArrayList<>();
        this.tiempoTotal = 0;
        this.indiceActualAtleta = 0;
    }

    public void agregarAtleta(Atleta atleta) {
        atletas.add(atleta);
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public ArrayList<Atleta> getAtletas() {
        return atletas;
    }

    public void actualizarTiempoTotal(long tiempo) {
        this.tiempoTotal += tiempo;
    }

    public long getTiempoTotal() {
        return tiempoTotal;
    }

    // Lanza la carrera
    public void iniciarCarrera() {
        if (atletas != null && !atletas.isEmpty()) {
            atletas.get(indiceActualAtleta).start();
        }
    }

    // Método sincronizado para pasar la posta al siguiente atleta
    public synchronized void pasarPostaAlSiguiente() {
        // Aumenta el índice del siguiente atleta
        if (indiceActualAtleta + 1 < atletas.size()) {
            indiceActualAtleta++;
            // Lanza el siguiente atleta
            atletas.get(indiceActualAtleta).start();
        }
    }

    // Esperar a que todos los atletas terminen la carrera
    public void esperarResultados() throws InterruptedException {
        for (Atleta atleta : atletas) {
            atleta.join();  // Espera que termine cada atleta
        }
    }
}
